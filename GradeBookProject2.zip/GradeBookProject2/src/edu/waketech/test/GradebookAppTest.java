package edu.waketech.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

import edu.waketech.academic.Assignment;
import edu.waketech.academic.Course;
import edu.waketech.common.Student;
import edu.waketech.common.StudentBody;
import edu.waketech.GradebookApp;

class GradebookAppTest {


	@Test
	void testCreateAssignment() {
		Course course = new Course("CSC", 251);
		Student s1 = new Student("last1", "first1", 2);
		Student s2 = new Student("last2", "first2", 3);
		StudentBody sb = StudentBody.getInstance();
		sb.add(s1);
		sb.add(s2);
		
		course.addStudent(s1.getId());
		course.addStudent(s2.getId());
		
		GradebookApp.createAssignment(course, "lab1", 50);
		List<Assignment> labList = course.getAssignment(s1.getId(), "lab1");
		Assignment foundLab = labList.get(0);
		assertEquals("lab1", foundLab.getName());
		assertEquals(50, foundLab.getPossiblePoints());
		assertTrue(foundLab.getScore() >= 35);
	}
	
	@Test
	void testCreateAssignment1() {
		Course course = new Course("CSC", 251);
		Student s1 = new Student("last1", "first1", 2);
		Student s2 = new Student("last2", "first2", 3);
		StudentBody sb = StudentBody.getInstance();
		sb.add(s1);
		sb.add(s2);
		
		course.addStudent(s1.getId());
		course.addStudent(s2.getId());
		
		GradebookApp.createAssignment(course, "lab1", 50);
		List<Assignment> labList = course.getAssignment(s2.getId(), "lab1");
		Assignment foundLab = labList.get(0);
		assertEquals("lab1", foundLab.getName());
		assertEquals(50, foundLab.getPossiblePoints());
		assertTrue(foundLab.getScore() >= 35);
	}


	@Test
	void testGetStudentsTakingEverything() {
		List<Course> courses = new ArrayList<>();
		Course course = new Course("CSC", 174);
		Course course2 = new Course("CSC", 252);
		courses.add(course);
		courses.add(course2);
		Student s1 = new Student("last1", "first1", 2);
		Student s2 = new Student("last2", "first2", 3);
		Student s3 = new Student("last3", "first3", 4);
		StudentBody sb = StudentBody.getInstance();
		sb.add(s1);
		sb.add(s2);
		sb.add(s3);
		
		course.addStudent(s1.getId());
		course.addStudent(s2.getId());
		course2.addStudent(s1.getId());
		
		assertEquals(1, GradebookApp.getStudentsTakingEverything(courses).size());
		course2.addStudent(s3.getId());
		course.addStudent(s3.getId());
		assertTrue(2 == GradebookApp.getStudentsTakingEverything(courses).get(0));
		assertTrue(4 == GradebookApp.getStudentsTakingEverything(courses).get(1));
		
	}

	// TODO
	@Test
	void testCourseAverageForAssignment() {
		Course course = new Course("CSC", 251);
		Student s1 = new Student("last1", "first1", 2);
		Student s2 = new Student("last2", "first2", 3);
		Student s3 = new Student("last3", "first3", 4);
		StudentBody sb = StudentBody.getInstance();
		sb.add(s1);
		sb.add(s2);
		sb.add(s3);
		
		course.addStudent(s1.getId());
		course.addStudent(s2.getId());
		course.addStudent(s3.getId());
		
		//GradebookApp.createAssignment(course, "lab1", 50);
		Assignment lab1 = new Assignment("lab1", 50, 45);
		course.addAssignment(s1.getId(), lab1);
		Assignment lab1v2 = new Assignment("lab1", 50, 50);
		course.addAssignment(s2.getId(), lab1);
		Assignment lab1v3 = new Assignment("lab1", 50, 40);
		course.addAssignment(s3.getId(), lab1);
		
		//System.out.println(course);
		
		double averageLab1 = GradebookApp.courseAverageForAssignment(course , "lab1");
		assertEquals(45, averageLab1);
	}
	
	// TODO
	@Test
	void testCalculateStudentAverageInOneCourse() {
		Course course = new Course("CSC", 251);
		Student s1 = new Student("last1", "first1", 2);
		StudentBody sb = StudentBody.getInstance();
		sb.add(s1);

		
		course.addStudent(s1.getId());
		Assignment lab1 = new Assignment("lab1", 50, 45);
		course.addAssignment(s1.getId(), lab1);
		Assignment lab2 = new Assignment("lab2", 50, 50);
		course.addAssignment(s1.getId(), lab2);
		Assignment lab3 = new Assignment("lab3", 50, 40);
		course.addAssignment(s1.getId(), lab3);
		Assignment test1 = new Assignment("test1", 100, 90);
		course.addAssignment(s1.getId(), test1);
		
		double average1Student = GradebookApp.calculateStudentAverageInOneCourse(course, s1.getId());
		assertEquals(56.25, average1Student);
		
	}
	
}
